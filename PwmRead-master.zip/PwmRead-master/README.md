# PwmRead
Arduino library to read a PWM value through a low pass filter and buffer the value
